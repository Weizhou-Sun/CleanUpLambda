import boto3
import logging

'''
This is a termination lambda function that 
* trigered up the cloudwatch crontabl event
* scans all the EC2 instances
* 
'''

ec2_client = boto3.client('ec2')
ec2 = boto3.resource('ec2')

def retrieve_deletable_instance_id():
    response = ec2_client.describe_instances()


def lambda_handler(event, context):
    
